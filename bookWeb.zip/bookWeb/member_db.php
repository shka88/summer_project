<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
    
   
    <script type="text/javascript">
        $(document).ready(function(){
            $("#headers").load("header.html");
            $("#footers").load("footer.html");
        });
    </script>
    <title>Document</title>
    <style>
        #nombre{
            width: 550px;
        }
    </style>
  
</head>
<body>
    <header>
        <div id="headers"></div>
    </header>
    <?php
                $db_hostnmae = '127.0.0.1';
                $db_database = 'pro_user';
                $db_username = 'kayon';
                $db_password = '5284';

                $db_server = new mysqli($db_hostnmae, $db_username, $db_password, $db_database, 3306);
                if(!$db_server)
                    echo "DB Server connect Error<br>";

                else
                    echo "DB Server connect<br>";

                
                $p_id = $_POST['id'];
                $p_pw = $_POST['pw'];
                $p_name = $_POST['name'];
                $p_add = $_POST['add'];
                $p_email = $_POST['email'];


                $Insert = "INSERT INTO singup(
                    p_id, p_pw, p_name, p_add, p_email) VALUES(
                    '$p_id','$p_pw','$p_name','$p_add','$p_email')";
                $result = mysqli_query($db_server, $Insert);
                if($result == false){
                    echo mysqli_error($db_server);
                }  

                //select ex
                // $Select = "SELECT * FROM forum";
                // $result = mysqli_query($db_server, $Select);
                // while($board = $result->fetch_array())
                // {
                // $p_no = $board['p_no'];
                // $p_id = $board['p_id'];
                // $p_pw = $board['p_pw'];
                // $p_name = $board['p_name'];
                // $p_email = $board['p_email'];
                // }

?>
<script type="text/javascript">alert('회원가입이 완료되었습니다.');</script>
    <footer class="footer">   
        <div id="footers" style="right: 0;"></div>
    </footer>
</body>
</html>