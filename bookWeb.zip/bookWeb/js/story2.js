// optional
$('#blogCarousel').carousel({
    interval: 5000
});
