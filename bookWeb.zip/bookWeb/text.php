<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <!-- <link rel="stylesheet" href="css/style4.css"> -->
    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">


    <title>Laravel</title>
    <script type="text/javascript">
        $(document).ready(function(){
            $("#headers").load("header.html");
            $("#footers").load("footer.html");
        });
    </script>

    <style>
        .how-section1{
            margin-top:-15%;
            padding: 10%;
        }
        .how-section1 h4{
            color: #ffa500;
            font-weight: bold;
            font-size: 30px;
        }
        .how-section1 .subheading{
            color: #3931af;
            font-size: 20px;
        }
        .how-section1 .row
        {
            margin-top: 10%;
        }
        .how-img 
        {
            text-align: center;
        }
        .how-img img{
            width: 40%;
        }
        </style>
</head>
<body>
    <header>
        <!-- <div id="headers"></div> -->
    </header>
   
    <div class="container">
       <div class="row">
           <table class="table table-striped" style="text-align: center; border: 1px solid #dddddd">
                <thead>
                    <tr>
                        <th style="background-color: #eeeeee; text-align: center;">번호</th>
                        <th style="background-color: #eeeeee; text-align: center;">아이디</th>
                        <th style="background-color: #eeeeee; text-align: center;">유형</th>
                        <th style="background-color: #eeeeee; text-align: center;">제목</th>
                        <th style="background-color: #eeeeee; text-align: center;">내용</th>
                        <th style="background-color: #eeeeee; text-align: center;">입력날짜</th>
                    </tr>
                </thead>
           

           <?php
                $db_hostnmae = '127.0.0.1';
                $db_database = 'user_info';
                $db_username = 'kayon';
                $db_password = '5284';

                $db_server = new mysqli($db_hostnmae, $db_username, $db_password, $db_database, 3306);
                // if(!$db_server)
                //     echo "DB Server connect Error<br>";

                // else
                //     echo "DB Server connect<br>";

                
                $u_id = $_POST['id'];
                $u_type = $_POST['type'];
                $u_title = $_POST['title'];
                $u_content = $_POST['content'];
                $u_date = $_POST['date'];


                $Insert = "INSERT INTO forum(
                    u_id, u_type, u_title, u_content, u_date) VALUES(
                    '$u_id','$u_type','$u_title','$u_content','$u_date')";
                $result = mysqli_query($db_server, $Insert);
                if($result == false){
                    echo mysqli_error($db_server);
                }  

                //select ex
                $Select = "SELECT * FROM forum";
                $result = mysqli_query($db_server, $Select);
                while($board = $result->fetch_array())
                {
                $u_no = $board['u_no'];
                $u_id = $board['u_id'];
                $u_type = $board['u_type'];
                $u_title = $board['u_title'];
                $u_content = $board['u_content'];
                $u_date = $board['u_date'];
                echo <<<END
                <tbody>
                    <tr>
                        <td width = "100">$u_no</td>
                        <td width = "100">$u_id</td>
                        <td width = "100">$u_type</td>
                        <td width = "100">$u_title</td>
                        <td width = "100">$u_content</td>
                        <td width = "100">$u_date</td>
                    </tr>
                </tbody>
END;
                }
                
?>
                </table>
</body>
</html>